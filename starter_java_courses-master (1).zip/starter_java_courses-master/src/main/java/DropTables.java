import database.SQLiteConnector;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DropTables {
    public static void main(String[] args) {
        Connection connection = SQLiteConnector.getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.execute("DROP TABLE IF EXISTS test_run");
            statement.execute("DROP TABLE IF EXISTS perf_logs");
            statement.execute("DROP TABLE IF EXISTS acc_data");

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
