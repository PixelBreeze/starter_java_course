package stepdefs;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;


public class Hooks {

    @Before
    public void initalizeEnvironment() {
        System.out.println("initalizeEnvironment");
    }

    @After
    public void freeResources() {
        System.out.println("freeResources");
    }

    @BeforeStep
    public void beforeStep() {
        System.out.println("beforeStep !!");
    }

    @AfterStep
    public void afterStep() {
        System.out.println("afterStep !!");
    }
}
