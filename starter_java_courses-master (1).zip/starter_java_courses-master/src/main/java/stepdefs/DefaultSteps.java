package stepdefs;
import cucumber.api.java.en.*;

public class DefaultSteps {
    @Given("^something$")
    public void something() {
        System.out.println("Woohoo");
    }
}
