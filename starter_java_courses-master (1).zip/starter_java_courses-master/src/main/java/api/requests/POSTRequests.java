package api.requests;

import api.handlers.SuccessAsCode;
import com.google.gson.Gson;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.io.IOException;


public class POSTRequests {
    static public Integer postJson(String url, Object requestBodyData) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        httpPost.addHeader("Content-type", "application/json");

        Gson gson = new Gson();
        StringEntity body = new StringEntity(gson.toJson(requestBodyData));
        httpPost.setEntity(body);

        Integer responseCode = httpClient.execute(httpPost, SuccessAsCode.responseHandler);

        httpClient.close();
        return responseCode;
    }
}

