package api.requests;

import api.handlers.SuccessAsJSONObject;
import api.handlers.SuccessAsString;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;

import java.io.IOException;

public class GETRequests {
    public static JSONObject getAsJSON(String url) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);
        JSONObject responseData = httpClient.execute(httpGet, SuccessAsJSONObject.responseHandler);
        httpClient.close();
        return responseData;
    }

    public static String getAsString(String url) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);
        String responseData = httpClient.execute(httpGet, SuccessAsString.responseHandler);
        httpClient.close();
        return responseData;
    }
}