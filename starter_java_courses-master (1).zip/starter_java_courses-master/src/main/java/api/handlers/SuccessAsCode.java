package api.handlers;

import org.apache.http.client.ResponseHandler;

public class SuccessAsCode {
    static public ResponseHandler<Integer> responseHandler =
            httpResponse -> httpResponse.getStatusLine().getStatusCode();
}