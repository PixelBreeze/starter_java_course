package database;

import java.sql.*;

public class SQLiteConnector {
    static public Connection getConnection() {
        Connection connection = null;

        try {
            connection = DriverManager.getConnection("jdbc:sqlite:data.db");
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Connection to database has been successfully established.");
        return connection;
    }
}
