import database.SQLiteConnector;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTables {
    public static void main(String[] args) {
        Connection connection = SQLiteConnector.getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.execute("CREATE TABLE test_run" +
                    "(id INTEGER PRIMARY KEY AUTOINCREMENT, name CHAR(50), EXEC_STATUS CHAR(10), EXEC_DATE TEXT)");

            statement.execute("CREATE TABLE perf_logs" +
                    "(id INTEGER PRIMARY KEY AUTOINCREMENT, step TEXT, EXEC_TIME INTEGER, test_id INTEGER, FOREIGN KEY (test_id) REFERENCES test_run(id))");

            statement.execute("CREATE TABLE acc_data" +
                    "(id INTEGER PRIMARY KEY AUTOINCREMENT, var_name CHAR(50), value TEXT, test_id INTEGER, FOREIGN KEY (test_id) REFERENCES test_run(id))");

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
