import database.SQLiteConnector;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ShowTables {
    public static void main(String[] args) {
        Connection connection = SQLiteConnector.getConnection();
        try {
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(
                    String.format("SELECT * FROM test_run")
            );
            while (result.next()) {
                System.out.print(result.getString("name")+" ");
                System.out.print(result.getString("EXEC_STATUS")+" ");
                System.out.print(result.getString("EXEC_DATE")+" ");
                System.out.println();
            }
            ResultSet result2 = statement.executeQuery(
                    String.format("SELECT * FROM perf_logs")
            );
            while (result2.next()) {
                System.out.print(result.getString("step")+" ");
                System.out.print(result.getString("EXEC_TIME")+" ");
                System.out.print(result.getString("test_id")+" ");
                System.out.println();
            }
            ResultSet result3 = statement.executeQuery(
                    String.format("SELECT * FROM acc_data")
            );
            while (result2.next()) {
                System.out.print(result.getString("var_name")+": ");
                System.out.print(result.getString("value")+" ");
                System.out.print(result.getString("test_id")+" ");
                System.out.println();
            }
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}