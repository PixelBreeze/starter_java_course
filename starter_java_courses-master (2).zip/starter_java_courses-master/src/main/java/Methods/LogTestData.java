package Methods;

import database.SQLiteConnector;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class LogTestData {
    public void logTestData(String varName,String varData, Integer id) {
        Connection connection = SQLiteConnector.getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate("INSERT INTO acc_data(var_name,value,test_id)"+"VALUES('"+varName+"','"+varData+"','"+id+"')");
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
