package Methods;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileWriter;

public class JsoupTester {

    public static void JsoupThing(String testName, String percentage){
        try{
            FileWriter fw=new FileWriter("C:\\Users\\714829\\Desktop\\test.html");
            String html = "<html><head><title>Test Runs</title></head>"
                    + "<body>"
                    + "<div id='tests'></div>"
                    +"</body></html>";
            Document document = Jsoup.parse(html);
            Element tests = document.getElementById("tests");
            fw.write(document.outerHtml());
            tests.html("<div class='testName'>"+testName+"</div>");
            tests.append("<div class='testPercentage'"+percentage+"</div>");
            fw.close();
        }catch(Exception e){System.out.println(e);}
    }

    public static void calculate(){

    }

    public static void main(String[] args) {
        JsoupThing(null, null);
    }
}
