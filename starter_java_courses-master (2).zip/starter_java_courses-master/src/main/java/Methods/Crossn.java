package Methods;

import org.apache.commons.lang.RandomStringUtils;

public class Crossn {
    public static void main(String[] args) {
        Integer checksum=0;
        String validSSN;
        String rngSSN =  RandomStringUtils.random(10, false, true);
        for (char number: rngSSN.toCharArray()) {
            checksum = checksum + Integer.parseInt(String.valueOf(number));
            checksum = checksum % 10;
            if(checksum==0) {
                checksum = 10;
            }
            checksum = checksum * 2 % 11;
        }
        checksum = 11 - checksum;
        if(checksum==10) {
            checksum = 0;
        }
        String.valueOf(checksum);
        validSSN = "HR"+rngSSN+checksum;
        System.out.println(validSSN);
    }
}

