package stepdefs;
import Methods.JsonReader;
import Methods.LogTestData;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.*;
import database.SQLiteConnector;
import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.io.IOException;

public class DefaultSteps {
    private WebDriver driver = null;
    private String rngPin = "";
    private String testName = "";
    private String nowDate = "";
    private Integer testId =0;
    private boolean timer = false;
    private long startTime = 0;
    private long endTime = 0;
    private int stepCounter = 0;

    public void GetStepTime(String stepName) {
        if (timer==false) {
            startTime = System.currentTimeMillis();
            timer = true;
        } else {
            //increment step
            stepCounter++;
            //get time
            endTime = System.currentTimeMillis() - startTime;
            startTime = 0;
            timer = false;
            //insert into db step
            Connection connection = SQLiteConnector.getConnection();
            try {
                Statement statement = connection.createStatement();
                statement.executeUpdate("INSERT INTO perf_logs(step,EXEC_TIME,test_id)"+"VALUES('"+stepName+"','"+endTime+"','"+testId+"')");
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Given("^test name is \"([^\"]*)\"$")
    public void SetupTest(String testName) {
        GetStepTime(null);
        String testStatus = "FAILED";
        this.testName = testName;
        nowDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date());
        Connection connection = SQLiteConnector.getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate("INSERT INTO test_run(name,EXEC_STATUS,EXEC_DATE)"+"VALUES('"+testName+"','"+testStatus+"','"+nowDate+"')");
            ResultSet result = statement.executeQuery(
                    String.format("SELECT id FROM test_run WHERE EXEC_DATE='%s'", nowDate)
            );
            testId = result.getInt("id");
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        GetStepTime("Test_Name");
    }

    @After
    public void afterTest(Scenario scenario){
        String testStatus;
        System.out.println("Inserting run into db");
        stepCounter = 0;
        timer = false;
        Connection connection = SQLiteConnector.getConnection();
        if(scenario.isFailed()){
            testStatus = "FAILED";
        } else {
            testStatus = "PASSED";
        }
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate("update test_run set EXEC_STATUS ='"+testStatus+"' WHERE id="+testId+"");
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        driver.quit();
    }

    @Given("^web page url is \"([^\"]*)\"$")
    public void chromeIsOpened(String webpageUrl) {
        GetStepTime(null);
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--disable-notifications");
        chromeOptions.addArguments("--ignore-certificate-errors");
        System.setProperty("webdriver.chrome.driver", "lib/chromedriver.exe");
        chromeOptions.addArguments("--test-type");
        driver = new ChromeDriver(chromeOptions);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        driver.navigate().to(webpageUrl);
        GetStepTime("Open_Webpage");
    }

    @When("^I find new valid customer pin$")
    public void getValidPin() {
        GetStepTime(null);
        String pinStatus = "";
        do {
            rngPin =  RandomStringUtils.random(5, false, true);
            JsonReader jsonReader = new JsonReader();
            try {
                JSONObject json = jsonReader.readJsonFromUrl("https://custom-crm-ac.herokuapp.com/checkPin?pin=" + rngPin);
                pinStatus = json.get("pinStatus").toString();
                System.out.println(json.toString());
            } catch (IOException e) {
            }
        } while (pinStatus.equals("INVALID"));
        GetStepTime("Find_Valid_Pin");
    }

    @When("^I find invalid customer pin$")
    public void getInvalidPin() {
        GetStepTime(null);
        String pinStatus = "";
        do {
            rngPin =  RandomStringUtils.random(5, false, true);
            JsonReader jsonReader = new JsonReader();
            try {
                JSONObject json = jsonReader.readJsonFromUrl("https://custom-crm-ac.herokuapp.com/checkPin?pin=" + rngPin);
                pinStatus = json.get("pinStatus").toString();
                System.out.println(json.toString());
            } catch (IOException e) {
            }
        } while (pinStatus.equals("VALID"));
        GetStepTime("Find_Invalid_Pin");
    }

    @When("^go to customer creation$")
    public void clickCustomerCreation() {
        GetStepTime(null);
        WebElement button = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/a"));
        button.click();
        GetStepTime("Navigate_CC");
    }

    @When("^set random value in \"([^\"]*)\"$")
    public void setField(String fieldName) {
        LogTestData logObject = new LogTestData();
        GetStepTime(null);
        WebElement Field = driver.findElement(
                By.xpath("//div[@class='input-field-div'][text()='"+fieldName+":']/input")
        );
        if(fieldName.equals("PIN")){
            Field.sendKeys(rngPin);
            logObject.logTestData(fieldName,rngPin,testId);
        } else {
            String rngString = RandomStringUtils.random(6, true, false);
            Field.sendKeys(rngString);
            logObject.logTestData(fieldName,rngString,testId);
        }
        GetStepTime("Set_Field");
    }

    @When("^set saved pin in \"([^\"]*)\"$")
    public void setPin(String fieldName) {
        setField(fieldName);
    }

    @When("^click the \"([^\"]*)\" button")
    public void clickButton(String buttonName){
        GetStepTime(null);
        driver.findElement(By.xpath("//button[text()='"+buttonName+"']")).click();
        GetStepTime("Click_Button");
    }

    @When("^I'm navigated to home screen$")
    public void checkPage(){
        GetStepTime(null);
        WebDriverWait waiter = new WebDriverWait(driver, 3);
        waiter.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//*[@id=\"root\"]/div/div/div[1]/a"))
        );
        Assert.assertEquals("Customer was indeed saved!", "https://custom-crm-ac.herokuapp.com/", driver.getCurrentUrl());
        GetStepTime("Navigated_Home");
    }

    @When("^presented with message \"([^\"]*)\"$")
    public void checkMessage(String msg){
        GetStepTime(null);
        WebElement saveResponseMsg = driver.findElement(By.xpath("//*[@id=\"message_box\"]"));
        Assert.assertEquals("The expected message was found.", msg, saveResponseMsg.getText());
        GetStepTime("Find_Message");
    }

    @When("^there is no error message$")
    public void noErrorMsg(){
        GetStepTime(null);
        GetStepTime("No_Message");
    }

}
